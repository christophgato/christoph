import numpy as np

def f(lista_x):
  """
  input : lista_x = vector
  output: cada entrada del vector al cuadrado
  """
  return [x**2 for x in lista_x]

def g(lista_x, lista_y):
  """
  input : lista_x = vector
          lista_y = vector
          Los vectores deben tener la misma cantidad de entradas
  output: Se calcula para coordenada i de los vectores el valor sin(x_i)cos(y_i) mediante zip(), y se ingresan los valores en un vector
  """
  return [float(np.sin(x) * np.cos(y)) for x, y in zip(lista_x, lista_y)]

def h(lista_x, lista_y, lista_z):
  """
  input:  lista_x = vector
          lista_y = vector
          lista_z = vector
          Los vectores deben tener la misma cantidad entradas 
  output: Se calcula para cada coordenada i de los vectores el valor (x_i)(y_i)(z_i) mediante zip(), y se ingresan los valores en un vector  

  """
  return [x * y * z for x, y, z in zip(lista_x, lista_y, lista_z)]



class Funcion:
    def __init__(self, nombre, parametros, funcion):
        """
        Se inicializa una función matemática genérica.

        nombre: Nombre de la función (ej. "f", "g", "h").
        parametros: Nombres de los parámetros (ej. ["x"], ["x", "y"]).
        funcion: Operación matemática de la función.
        """
        self.nombre = nombre
        self.parametros = parametros
        self.funcion = funcion

    def evaluar(self, *valores):
        """
        Evalúa la función con los valores dados.

        valores: valores de entrada (vectores) para la función (el número de vectores debe coincidir con el número de parámetros de la función).
        return: Resultado de evaluar la función con los valores dados.
        """
        if len(valores) != len(self.parametros):
            raise ValueError(f"La función {self.nombre} requiere {len(self.parametros)} valores de entrada, pero se proporcionaron {len(valores)}.")
        
        return self.funcion(*valores)

    def __str__(self):
        """ Representación de la función en formato legible. """
        return "".join([self.nombre, "(", ", ".join(self.parametros), ")"])



















